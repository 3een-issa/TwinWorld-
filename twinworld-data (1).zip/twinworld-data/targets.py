# Target fingerprints with sources and verification status.
# status: "verified" = found in a published source during research
#         "todo" = still needs to be looked up

SHACKLETON = {
    "name": "Shackleton Crater",
    "body": "Moon",
    "lat": -89.9,
    "diameter_km": {"value": 21.0, "status": "verified",
                    "source": "JAXA KAGUYA press release (2008); Zuber et al. 2012"},
    "depth_km": {"value": 4.1, "status": "verified",
                 "source": "NASA LOLA, Zuber et al. 2012 (4.1 +/- 0.05 km)"},
    "wall_slope_deg": {"value": 30.0, "status": "verified",
                       "source": "JAXA KAGUYA Terrain Camera (2008)"},
    "floor_diameter_km": {"value": 6.6, "status": "verified",
                          "source": "JAXA KAGUYA Terrain Camera (2008)"},
    "floor_temp_K": {"value": 90.0, "status": "verified",
                     "source": "Estimated from crater shape, KAGUYA (2008); "
                               "NOT matchable on Earth"},
    "rim_illumination_pct": {"value": 85.0, "status": "verified",
                             "source": "Peaks lit 80-90% of each lunar orbit (multiple sources)"},
    "rms_roughness_m": {"value": None, "status": "todo",
                        "source": "Table in Zuber et al. 2012, Nature 486, 378-381"},
    "vegetation_ndvi": {"value": 0.0, "status": "verified",
                        "source": "No vegetation on the Moon"},
}

if __name__ == "__main__":
    for key, v in SHACKLETON.items():
        if isinstance(v, dict):
            print(f"{key:24s} {str(v['value']):8s} [{v['status']}]")