import json
import os
import pandas as pd
from reference_sites import REFERENCE_SITES, HYPOTHESES, SOURCES

pool = pd.read_csv('scores_test_4dim.csv')

# Keep every grid cell, the documented reference sites, and the sites named in hypotheses
ref_by_site = {r['site']: r for r in REFERENCE_SITES}
expected_names = {e['site'] for h in HYPOTHESES.values() for e in h['expected']}
keep_names = set(ref_by_site) | expected_names

is_grid = pool['kind'] == 'grid'
keep = pool['site'].isin(keep_names)
dropped = pool.loc[~is_grid & ~keep, 'site'].tolist()
missing = [s for s in keep_names if s not in set(pool['site'])]
pool = pool[is_grid | keep].reset_index(drop=True)
print(f"Documented reference sites: {len(ref_by_site)}")
print(f"Extra sites kept only as expectations: {len(expected_names - set(ref_by_site))}")
print(f"Sites dropped: {len(dropped)}")
if missing:
    print("WARNING: not found in the data (name mismatch?):", missing)

RAW = {'steep': 'slope_mean', 'veg': 'ndvi_mean',
       'temp': 'mean_temp_mean', 'dry': 'precip_mm'}
LABELS = {'steep': 'topography', 'temp': 'thermal',
          'dry': 'dryness', 'veg': 'vegetation'}

# Percentile of each raw value within the pool (0..1)
pct = {k: pool[c].rank(pct=True) for k, c in RAW.items()}

def build(dims):
    """Score every place in the pool with a profile. dims = {dim: (direction, weight)}."""
    dim_scores = {}
    for d, (direction, w) in dims.items():
        dim_scores[d] = pct[d] if direction == +1 else 1 - pct[d]
    total = sum(dim_scores[d] * w for d, (_, w) in dims.items())
    df = pool[['site', 'kind', 'lat', 'lon']].copy()
    df['score'] = total
    for d in dim_scores:
        df[LABELS[d]] = dim_scores[d]
    df = df.sort_values('score', ascending=False).reset_index(drop=True)
    df['rank'] = df.index + 1
    return df

# Documented targets. Weights and directions are OUR ASSUMPTIONS (document in Methodology).
PROFILES = {
    'shackleton': {
        'name': 'Shackleton Crater', 'body': 'Moon',
        'dims': {'steep': (+1, 0.35), 'temp': (-1, 0.30),
                 'dry': (-1, 0.20), 'veg': (-1, 0.15)},
    },
    'jezero': {
        'name': 'Jezero Crater', 'body': 'Mars',
        'dims': {'steep': (-1, 0.30), 'dry': (-1, 0.35),
                 'veg': (-1, 0.20), 'temp': (-1, 0.15)},
    },
    'gale': {
        'name': 'Gale Crater', 'body': 'Mars',
        'dims': {'dry': (-1, 0.40), 'veg': (-1, 0.30), 'temp': (-1, 0.30)},
    },
        'tranquillitatis': {
        'name': 'Mare Tranquillitatis (Apollo 11)', 'body': 'Moon',
        'dims': {'steep': (-1, 0.40), 'dry': (-1, 0.30), 'veg': (-1, 0.30)},
    },
    # Same profile as Tranquillitatis: its defining sulfate/hematite chemistry is not measured
    'meridiani': {
        'name': 'Meridiani Planum (Opportunity)', 'body': 'Mars',
        'dims': {'steep': (-1, 0.40), 'dry': (-1, 0.30), 'veg': (-1, 0.30)},
    },
}

def analogs_for(tid):
    out = []
    for r in REFERENCE_SITES:
        for l in r['links']:
            if l['target'] == tid:
                out.append({'site': r['site'], 'strength': l['strength'],
                            'source': SOURCES[l['source']], 'note': r['why']})
    out.sort(key=lambda a: a['strength'] != 'direct')
    return out

output = {'targets': {}, 'results': {}, 'known_ranks': {}, 'validation': {}}
score_cols = {}

for tid, prof in PROFILES.items():
    df = build(prof['dims'])
    score_cols[tid] = df.set_index('site')['score']

    output['targets'][tid] = {
        'name': prof['name'], 'body': prof['body'],
        'weights': {LABELS[d]: w for d, (_, w) in prof['dims'].items()},
        'directions': {LABELS[d]: direction for d, (direction, _) in prof['dims'].items()},
    }
    output['results'][tid] = df.head(10).round(3).to_dict(orient='records')

    known = df[df['kind'] == 'known'].reset_index(drop=True)
    output['known_ranks'][tid] = known[['site', 'rank', 'score']].round(3).to_dict(orient='records')

    n = len(df)
    rank_of = dict(zip(df['site'], df['rank']))
    score_of = dict(zip(df['site'], df['score']))
    known_rank = {s: i + 1 for i, s in enumerate(known['site'])}
    val = []
    for a in analogs_for(tid):
        s = a['site']
        row = dict(a)
        if s in rank_of:
            row.update({'rank': int(rank_of[s]), 'of': int(n),
                        'top_percent': round(100.0 * rank_of[s] / n, 1),
                        'rank_among_known': int(known_rank[s]),
                        'known_total': int(len(known)),
                        'score': round(float(score_of[s]), 3)})
        else:
            row.update({'rank': None, 'note_missing': 'not scored (incomplete data)'})
        val.append(row)
    output['validation'][tid] = val

    print(f"\n=== {prof['name']} ({prof['body']}) : top 5 ===")
    print(df[['rank', 'site', 'score']].head(5).round(2).to_string(index=False))
    if val:
        print("--- documented analogs ---")
        for v in val:
            if v['rank'] is None:
                print(f"  {v['site']}: not scored")
            else:
                print(f"  {v['site']}: rank {v['rank']} of {v['of']} "
                      f"(top {v['top_percent']}%) [{v['strength']}]")
    else:
        print("--- no documented analogs for this target ---")

both = pd.DataFrame(score_cols)
print("\nSpearman rank correlation between targets:")
print(both.corr(method='spearman').round(2).to_string())

# ---------------- Hypotheses (not documented, not part of validation) ----------------
output['hypotheses'] = {}
print("\n##### HYPOTHESES (not documented) #####")
for hid, h in HYPOTHESES.items():
    entry = {'name': h['name'], 'body': h['body'], 'scored': h['scored'],
             'basis': h['basis'], 'expected': []}
    rank_of, n = {}, 0
    if h['scored']:
        hdf = build(h['dims'])
        n = len(hdf)
        rank_of = dict(zip(hdf['site'], hdf['rank']))
        entry['weights'] = {LABELS[d]: w for d, (_, w) in h['dims'].items()}
        entry['directions'] = {LABELS[d]: direction for d, (direction, _) in h['dims'].items()}
        entry['top5'] = hdf.head(5)[['site', 'rank', 'score']].round(3).to_dict(orient='records')
    for e in h['expected']:
        row = {'site': e['site'], 'why': e['why']}
        if h['scored'] and e['site'] in rank_of:
            row.update({'rank': int(rank_of[e['site']]), 'of': int(n),
                        'top_percent': round(100.0 * rank_of[e['site']] / n, 1)})
        entry['expected'].append(row)
    output['hypotheses'][hid] = entry

    print(f"\n{h['name']} ({h['body']}) - {'ranked' if h['scored'] else 'NOT ranked'}")
    for r in entry['expected']:
        if 'rank' in r:
            print(f"  expected {r['site']}: rank {r['rank']} of {r['of']} (top {r['top_percent']}%)")
        else:
            print(f"  expected {r['site']}: (no ranking)")

# Why each reference site is on the map
output['reference'] = {
    r['site']: {'body': r['body'], 'why': r['why'],
                'links': [{'target': l['target'], 'strength': l['strength'],
                           'source': SOURCES[l['source']]} for l in r['links']]}
    for r in REFERENCE_SITES
}
for s in expected_names - set(ref_by_site):
    output['reference'][s] = {'body': 'Expectation only',
                              'why': 'Kept on the map as our own expectation (no documented source)',
                              'links': []}

# Full pool (raw percentiles) so the browser can re-score live
pool_out = pool[['site', 'kind', 'lat', 'lon']].copy()
pool_out['topography'] = pct['steep']
pool_out['thermal'] = pct['temp']
pool_out['dryness'] = pct['dry']
pool_out['vegetation'] = pct['veg']
output['pool'] = pool_out.round(4).to_dict(orient='records')

with open('scores.json', 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)
print("\nSaved scores.json")

os.makedirs('site', exist_ok=True)
with open('site/scores_data.js', 'w', encoding='utf-8') as f:
    f.write('window.SCORES = ' + json.dumps(output, ensure_ascii=False) + ';')
print("Saved site/scores_data.js")