import pandas as pd

df = pd.read_csv('earth_grid.csv')
print("Total rows:", len(df))

# Cells with no valid data (mostly water)
empty = df['elevation_mean'].isna()
print("Cells with no elevation (water or missing):", empty.sum())

valid = df[~empty]
print("Valid land cells:", len(valid))

print("\nSummary of valid cells:")
print(valid[['elevation_mean', 'slope_mean', 'thermal_range_mean',
             'mean_temp_mean', 'ndvi_mean']].describe().round(2).to_string())

print("\nFirst 5 rows:")
print(df.head().round(2).to_string())