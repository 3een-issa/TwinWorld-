import ee
import pandas as pd
import os

ee.Initialize(project='twinworld-spaceapps')

# ===== Settings =====
LON_MIN, LON_MAX = 34, 60     # test region (Arabian Peninsula + Levant)
LAT_MIN, LAT_MAX = 12, 34
CELL = 1.0                    # cell size in degrees (~111 km)
SCALE = 250                   # unified analysis scale (meters)
BATCH = 100                   # cells per request
OUT = 'earth_grid.csv'

proj = ee.Projection('EPSG:4326').atScale(SCALE)

# Elevation: NASADEM where available, GMTED2010 for polar areas
nasadem = (ee.Image('NASA/NASADEM_HGT/001').select('elevation').toFloat()
           .reduceResolution(ee.Reducer.mean(), maxPixels=1024).reproject(proj))
gmted = (ee.Image('USGS/GMTED2010').select('be75')
         .rename('elevation').toFloat().reproject(proj))

elevation = ee.ImageCollection([gmted, nasadem]).mosaic().rename('elevation')
slope = ee.ImageCollection([ee.Terrain.slope(gmted),
                            ee.Terrain.slope(nasadem)]).mosaic().rename('slope')

# MODIS land surface temperature
lst = (ee.ImageCollection('MODIS/061/MOD11A2')
       .filterDate('2023-01-01', '2024-01-01'))
day = lst.select('LST_Day_1km').mean().multiply(0.02).subtract(273.15)
night = lst.select('LST_Night_1km').mean().multiply(0.02).subtract(273.15)
thermal_range = day.subtract(night).rename('thermal_range')
mean_temp = day.add(night).divide(2).rename('mean_temp')

# MODIS vegetation index
ndvi = (ee.ImageCollection('MODIS/061/MOD13A2')
        .filterDate('2023-01-01', '2024-01-01')
        .select('NDVI').mean().multiply(0.0001).rename('ndvi'))

stack = (elevation.addBands(slope).addBands(thermal_range)
         .addBands(mean_temp).addBands(ndvi))

reducer = ee.Reducer.mean().combine(ee.Reducer.stdDev(), sharedInputs=True)

# ===== Build the grid =====
cells = []
lat = LAT_MIN
while lat < LAT_MAX:
    lon = LON_MIN
    while lon < LON_MAX:
        cells.append((round(lat + CELL / 2, 3), round(lon + CELL / 2, 3)))
        lon += CELL
    lat += CELL
print(f"Total cells: {len(cells)}")

# Resume from where we stopped
done = set()
if os.path.exists(OUT):
    old = pd.read_csv(OUT)
    done = set(zip(old['lat'], old['lon']))
    print(f"Already done: {len(done)}")
todo = [c for c in cells if c not in done]

# ===== Run in batches =====
for i in range(0, len(todo), BATCH):
    chunk = todo[i:i + BATCH]
    feats = [ee.Feature(
        ee.Geometry.Rectangle([lon - CELL/2, lat - CELL/2,
                               lon + CELL/2, lat + CELL/2]),
        {'lat': lat, 'lon': lon}) for lat, lon in chunk]
    fc = ee.FeatureCollection(feats)
    try:
        res = stack.reduceRegions(collection=fc, reducer=reducer,
                                  scale=SCALE, tileScale=4).getInfo()
    except Exception as e:
        print(f"ERR batch starting at {i}: {e}")
        continue
    rows = [f['properties'] for f in res['features']]
    df = pd.DataFrame(rows)
    df.to_csv(OUT, mode='a', header=not os.path.exists(OUT), index=False)
    print(f"Done {min(i + BATCH, len(todo))}/{len(todo)}")

print("Finished. Output file:", OUT)