
SOURCES = {
    'gale_2022': 'Frontiers in Astronomy and Space Sciences, editorial 2022, '
                 'doi:10.3389/fspas.2022.1031832 (Atacama and Devon Island vs Gale rocks)',
    'mars_2023': 'Frontiers in Astronomy and Space Sciences, editorial 2023, '
                 'doi:10.3389/fspas.2023.1208367 (Qaidam, Mojave, Atacama as Mars analog plains)',
    'csm_2010': 'Christian Science Monitor, "Nine places on Earth that mimic Mars terrain" (2010)',
    'wiki_ta': 'Wikipedia, "Terrestrial analogue site": Atacama as a close Mars-surface analog',
    'usgs_az': 'USGS, "Common analogs of northern Arizona" '
               '(usgs.gov/media/images/common-analogs-northern-arizona)',
    'nasa_salda': 'NASA Earth Observatory, "Jez-like Mars" '
                  '(science.nasa.gov/earth/earth-observatory/jez-like-mars-147041/)',
                      'ames_haughton': 'NASA Ames, Haughton-Mars Project, "Haughton Crater" page '
                     '(archived: ti.arc.nasa.gov/projects/haughton_field/haughton_crater.php)',
    'nasa_basalt': 'NASA, "What is BASALT?" '
                   '(nasa.gov/missions/analog-field-testing/what-is-basalt/)',
    'ati_hmp': 'Aerospace Testing International, Haughton-Mars Project article '
               '(list of active analog test sites; secondary source)',
    'foxweather_usgs': 'Fox Weather, Artemis geology team article quoting USGS scientist '
                       '(Iceland as a common Moon and Mars analog; secondary source)',
}

def L(target, strength, source):
    # strength: 'direct' = documented pair with this target,
    #           'general' = documented analog of the same body, not this target
    return {'target': target, 'strength': strength, 'source': source}

REFERENCE_SITES = [
    {'site': 'Atacama Desert, Chile', 'body': 'Mars',
     'why': 'Hyperarid, salt-rich soils; one of the closest Mars-surface analogs',
     'links': [L('gale', 'direct', 'gale_2022'), L('jezero', 'general', 'wiki_ta')]},
    {'site': 'Haughton Crater, Canada', 'body': 'Mars',
     'why': 'Impact crater on Devon Island; rock chemistry similar to Gale',
          'links': [L('gale', 'direct', 'gale_2022'), L('shackleton', 'direct', 'ames_haughton')]},
    {'site': 'Lake Salda, Turkey', 'body': 'Mars',
     'why': 'Carbonate shoreline and delta deposits similar to Jezero',
     'links': [L('jezero', 'direct', 'nasa_salda')]},
    {'site': 'Cinder Lake Crater Field, USA', 'body': 'Moon',
     'why': 'Crater field made to replicate part of Mare Tranquillitatis',
     'links': [L('tranquillitatis', 'direct', 'usgs_az')]},
    {'site': 'Qaidam Basin, China', 'body': 'Mars',
     'why': 'Hyperarid basin cited as a Mars analog plain',
     'links': [L('jezero', 'general', 'mars_2023'), L('gale', 'general', 'mars_2023')]},
    {'site': 'Mojave Desert, USA', 'body': 'Mars',
     'why': 'Desert basin cited as a Mars analog plain',
     'links': [L('jezero', 'general', 'mars_2023'), L('gale', 'general', 'mars_2023')]},
        {'site': 'Rio Tinto, Spain', 'body': 'Mars',
     'why': 'Acidic, sulfate-rich environment compared to Mars (e.g. Meridiani)',
     'links': [L('meridiani', 'direct', 'csm_2010'),
               L('jezero', 'general', 'csm_2010'), L('gale', 'general', 'csm_2010')]},
    {'site': 'Pilbara Craton, Australia', 'body': 'Mars',
     'why': 'Ancient rocks, analog for Martian phyllosilicate formation',
     'links': [L('jezero', 'general', 'csm_2010'), L('gale', 'general', 'csm_2010')]},
    {'site': 'Lonar Crater, India', 'body': 'Mars',
     'why': 'Basaltic impact crater studied alongside other Mars analogs',
     'links': [L('jezero', 'general', 'gale_2022'), L('gale', 'general', 'gale_2022')]},

    # USGS lists these as planetary analogs but does not tie them to our targets
    {'site': 'Black Point Lava Flow, Arizona, USA', 'body': 'Moon/Mars',
     'why': 'Basalt flow used for science-operations testing (USGS)', 'links': []},
    {'site': 'Hopi Buttes, Arizona, USA', 'body': 'Moon/Mars',
     'why': 'Volcanic field used for navigation and traverse planning (USGS)', 'links': []},
    {'site': 'Meteor Crater, Arizona, USA', 'body': 'Moon/Mars',
     'why': 'Well-preserved impact crater, analog for impact processes (USGS)', 'links': []},
    {'site': 'SP Mountain, Arizona, USA', 'body': 'Mars',
     'why': 'Basaltic volcanism; used to test Mars geologic mapping techniques (USGS)', 'links': []},
    {'site': 'Sunset Crater, Arizona, USA', 'body': 'Moon/Mars',
     'why': 'Analog for basaltic volcanism (USGS)', 'links': []},
    {'site': 'Verde Valley, Arizona, USA', 'body': 'Moon/Mars',
     'why': 'Analog for habitability: fluvial, lacustrine and spring deposits (USGS)', 'links': []},
         {'site': 'Kilauea, Hawaii, USA', 'body': 'Mars',
     'why': 'Basaltic volcano used by NASA BASALT as an early-Mars analog',
     'links': [L('jezero', 'general', 'nasa_basalt'), L('gale', 'general', 'nasa_basalt')]},
    {'site': 'Mauna Loa, Hawaii, USA', 'body': 'Moon/Mars',
     'why': 'Volcano hosting the HI-SEAS analog site',
     'links': [L('jezero', 'general', 'ati_hmp'), L('gale', 'general', 'ati_hmp')]},
    {'site': 'Iceland', 'body': 'Moon/Mars',
     'why': 'Described by a USGS scientist as a common Moon and Mars analog',
     'links': [L('jezero', 'general', 'foxweather_usgs'), L('gale', 'general', 'foxweather_usgs'),
               L('tranquillitatis', 'general', 'foxweather_usgs')]},
]
HYPOTHESES = {
    # ======================== MOON ========================
    'marius': {
        'name': 'Marius Hills', 'body': 'Moon', 'scored': False,
        'basis': 'Volcanic dome field with lava-tube skylights. Lava tubes are not described by slope, '
                 'temperature, rainfall or vegetation, so this region is not ranked.',
        'expected': [
            {'site': 'Lanzarote, Spain', 'why': 'Well-known lava tubes'},
            {'site': 'Lava Beds National Monument, USA', 'why': 'Many lava tube caves'},
            {'site': 'Kīlauea Volcano, Hawaii, USA', 'why': 'Active basaltic volcano with lava tubes'},
            {'site': 'Mauna Loa, Hawaii', 'why': 'Basaltic lava fields with lava tubes'},
        ],
    },
    'aristarchus': {
        'name': 'Aristarchus Plateau', 'body': 'Moon', 'scored': False,
        'basis': 'Volcanic plateau with sinuous rilles and dark pyroclastic deposits. Pyroclastic '
                 'chemistry is not measured, so no ranking.',
        'expected': [
            {'site': 'Sunset Crater, Arizona, USA', 'why': 'Cinder cone with pyroclastic deposits'},
            {'site': 'Icelandic Volcanic Fields, Iceland', 'why': 'Basaltic volcanic fields'},
        ],
    },
    'tycho': {
        'name': 'Tycho Crater', 'body': 'Moon', 'scored': False,
        'basis': 'Large young impact crater with steep walls and a central peak. Crater shape is not '
                 'one of our four measurements, so no ranking.',
        'expected': [
            {'site': 'Meteor Crater, Arizona, USA', 'why': 'Well-preserved impact crater'},
            {'site': 'Haughton Crater, Canada', 'why': 'Impact crater in a polar desert'},
            {'site': 'Ries Crater, Germany', 'why': 'Large impact structure'},
            {'site': 'Sudbury Impact Structure, Canada', 'why': 'Large impact structure'},
        ],
    },
    'highlands': {
        'name': 'Lunar highlands', 'body': 'Moon', 'scored': True,
        'dims': {'steep': (+1, 0.45), 'dry': (-1, 0.30), 'veg': (-1, 0.25)},
        'basis': 'Rugged, heavily cratered, bare terrain. Scored on steepness, dryness and bareness only.',
        'expected': [
            {'site': 'Laguna Negra, Chile', 'why': 'Steep high mountain terrain'},
            {'site': 'Atacama Desert, Chile', 'why': 'Dry, bare, rugged in places'},
        ],
    },
    'hadley_rille': {
        'name': 'Hadley Rille (Apollo 15)', 'body': 'Moon', 'scored': False,
        'basis': 'Sinuous lava channel. Channel shape is not one of our measurements, so no ranking.',
        'expected': [
            {'site': 'Kīlauea Volcano, Hawaii, USA', 'why': 'Lava channels and tubes'},
            {'site': 'Lava Beds National Monument, USA', 'why': 'Lava channels and tubes'},
        ],
    },
    'cabeus': {
        'name': 'Cabeus Crater', 'body': 'Moon', 'scored': True,
        'dims': {'temp': (-1, 0.60), 'dry': (-1, 0.20), 'veg': (-1, 0.20)},
        'basis': 'Cold, permanently shadowed polar crater. "Cold" means the coldest places among '
                 'those we scored; no place on Earth is this cold.',
        'expected': [
            {'site': 'Svalbard, Norway', 'why': 'High-latitude polar environment'},
            {'site': 'Haughton Crater, Canada', 'why': 'Arctic polar desert'},
        ],
    },
    'taurus_littrow': {
        'name': 'Taurus-Littrow valley (Apollo 17)', 'body': 'Moon', 'scored': False,
        'basis': 'Valley between tall massifs with dark volcanic glass deposits. Volcanic glass '
                 'is not measured, so no ranking.',
        'expected': [
            {'site': 'Hopi Buttes, Arizona, USA', 'why': 'Volcanic field with pyroclastic deposits'},
            {'site': 'Sunset Crater, Arizona, USA', 'why': 'Cinder cone with pyroclastic deposits'},
        ],
    },
    # ======================== MARS ========================
    'mars_north_pole': {
        'name': 'Mars north polar region', 'body': 'Mars', 'scored': True,
        'dims': {'temp': (-1, 0.60), 'veg': (-1, 0.20), 'dry': (-1, 0.20)},
        'basis': 'Among the coldest places on Mars. "Cold" means the coldest places among those we scored.',
        'expected': [
            {'site': 'Svalbard, Norway', 'why': 'High-latitude polar environment'},
            {'site': 'Haughton Crater, Canada', 'why': 'Arctic polar desert'},
        ],
    },
    'mars_dunes': {
        'name': 'Mars dune fields (e.g. Bagnold Dunes, Gale)', 'body': 'Mars', 'scored': False,
        'basis': 'Sand dunes. Our measurements cannot tell a dune field from other dry, bare ground, '
                 'so this region is not ranked.',
        'expected': [
            {'site': 'Namib Desert, Namibia', 'why': 'Large dune sea'},
            {'site': 'Death Valley, USA', 'why': 'Contains dune fields'},
        ],
    },
    'valles_marineris': {
        'name': 'Valles Marineris', 'body': 'Mars', 'scored': True,
        'dims': {'steep': (+1, 0.50), 'dry': (-1, 0.30), 'veg': (-1, 0.20)},
        'basis': 'Giant canyon system with very steep walls. Scored on steepness, dryness and bareness only.',
        'expected': [
            {'site': 'Moab, Utah, USA', 'why': 'Canyon country'},
            {'site': 'San Rafael Swell, Utah, USA', 'why': 'Canyon country'},
            {'site': 'Wadi Rum, Jordan', 'why': 'Sandstone canyons and cliffs'},
        ],
    },
    'olympus_mons': {
        'name': 'Olympus Mons', 'body': 'Mars', 'scored': False,
        'basis': 'Shield volcano about 600 km across, far larger than our 10 km measurement circles, '
                 'so no ranking.',
        'expected': [
            {'site': 'Mauna Loa, Hawaii', 'why': 'Large shield volcano'},
            {'site': 'Kīlauea Volcano, Hawaii, USA', 'why': 'Shield volcano'},
        ],
    },
    'mawrth_vallis': {
        'name': 'Mawrth Vallis', 'body': 'Mars', 'scored': False,
        'basis': 'Clay-rich ancient terrain. Clay mineralogy is not measured, so no ranking.',
        'expected': [
            {'site': 'Pilbara Craton, Australia', 'why': 'Analog for phyllosilicate formation (cited for Mars in general)'},
        ],
    },
    'elysium_plains': {
        'name': 'Elysium lava plains', 'body': 'Mars', 'scored': True,
        'dims': {'steep': (-1, 0.40), 'dry': (-1, 0.30), 'veg': (-1, 0.30)},
        'basis': 'Young, flat, dry, bare lava plains. Scored on flatness, dryness and bareness only.',
        'expected': [
            {'site': 'Black Point Lava Flow, Arizona, USA', 'why': 'Basalt lava flow'},
            {'site': 'SP Mountain, Arizona, USA', 'why': 'Basaltic volcanic terrain'},
        ],
    },
    'arsia_skylights': {
        'name': 'Arsia Mons skylights', 'body': 'Mars', 'scored': False,
        'basis': 'Lava-tube skylights on a large volcano. Lava tubes are not measured, so no ranking.',
        'expected': [
            {'site': 'Lava Beds National Monument, USA', 'why': 'Many lava tube caves'},
            {'site': 'Lanzarote, Spain', 'why': 'Well-known lava tubes'},
            {'site': 'Kīlauea Volcano, Hawaii, USA', 'why': 'Lava tubes'},
        ],
    },
    'gusev': {
        'name': 'Gusev Crater, Home Plate (Spirit)', 'body': 'Mars', 'scored': False,
        'basis': 'Silica-rich deposits that scientists compare to hot-spring deposits. '
                 'Chemistry is not measured, so no ranking.',
        'expected': [
            {'site': 'Yellowstone, USA', 'why': 'Hot-spring (hydrothermal) deposits'},
            {'site': 'Dallol, Ethiopia', 'why': 'Hydrothermal salt and acid springs'},
        ],
    },
}