import ee
import pandas as pd

ee.Initialize(project='twinworld-spaceapps')

# مواقع معروفة (الاسم, خط العرض, خط الطول)
SITES = [
    ("Wadi Rum, Jordan",        29.5739,  35.4216),
    ("Atacama Desert, Chile",  -24.5000, -69.2500),
    ("Haughton Crater, Canada", 75.3800, -89.8800),
    ("Death Valley, USA",       36.5323, -116.9325),
    ("Dallol, Ethiopia",        14.2417,  40.2989),
    ("Mauna Loa, Hawaii",       19.4795, -155.5922),
    ("Dry Valleys, Antarctica", -77.5000, 162.0000),
    ("Lut Desert, Iran",        30.5000,  59.0000),
    ("Harrat Rahat, Saudi",     24.0000,  40.0000),
    ("Lanzarote, Spain",        29.0469, -13.6310),
    ("Svalbard, Norway",        78.2232,  15.6267),
    ("Ries Crater, Germany",    48.8833,  10.5500),
]

RADIUS = 10000  # 10 كم

# طبقات ناسا
dem = ee.Image('NASA/NASADEM_HGT/001').select('elevation')
slope = ee.Terrain.slope(dem)

# MODIS حرارة السطح (Terra) - نحسب المدى اليومي: نهار - ليل
lst = (ee.ImageCollection('MODIS/061/MOD11A2')
       .filterDate('2023-01-01', '2024-01-01'))
day = lst.select('LST_Day_1km').mean().multiply(0.02).subtract(273.15)
night = lst.select('LST_Night_1km').mean().multiply(0.02).subtract(273.15)
thermal_range = day.subtract(night).rename('thermal_range')
mean_temp = day.add(night).divide(2).rename('mean_temp')

# MODIS NDVI (غطاء نباتي)
ndvi = (ee.ImageCollection('MODIS/061/MOD13A2')
        .filterDate('2023-01-01', '2024-01-01')
        .select('NDVI').mean().multiply(0.0001).rename('ndvi'))

# تجميع الطبقات
stack = (dem.rename('elevation')
         .addBands(slope.rename('slope'))
         .addBands(thermal_range)
         .addBands(mean_temp)
         .addBands(ndvi))

# متوسط + انحراف معياري ضمن كل منطقة
reducer = ee.Reducer.mean().combine(ee.Reducer.stdDev(), sharedInputs=True)

rows = []
for name, lat, lon in SITES:
    area = ee.Geometry.Point([lon, lat]).buffer(RADIUS)
    try:
        s = stack.reduceRegion(
            reducer=reducer, geometry=area, scale=1000, maxPixels=1e9
        ).getInfo()
        s['site'] = name
        s['lat'] = lat
        s['lon'] = lon
        rows.append(s)
        print(f"OK  {name}")
    except Exception as e:
        print(f"ERR {name}: {e}")

df = pd.DataFrame(rows)
df.to_csv('earth_samples.csv', index=False)
print(df.round(2).to_string())