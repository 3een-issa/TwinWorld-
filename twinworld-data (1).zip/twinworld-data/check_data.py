
import pandas as pd
import os

files = [
    "earth_samples_v2.csv",
    "earth_grid_land.csv",
    "precip.csv",
    "scores_test_4dim.csv"
]

for file in files:
    print("\n" + "=" * 40)
    print("File:", file)

    if os.path.exists(file):
        df = pd.read_csv(file)

        print("Rows:", len(df))
        print("Columns:", list(df.columns))
        print("Missing values:")
        print(df.isnull().sum())
    else:
        print("File not found!")
