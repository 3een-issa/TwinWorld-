import ee
import pandas as pd

ee.Initialize(project='twinworld-spaceapps')

# استخدام مجموعة بيانات IMERG المعتمدة مع اختيار نطاق زمني أوسع قليلاً للتأكد من توفر البيانات
precip = (ee.ImageCollection('NASA/GPM_L3/IMERG_MONTHLY_V06')
          .filterDate('2020-01-01', '2023-01-01')
          .select('precipitation')
          .mean()
          .multiply(ee.Image.constant(24 * 365))
          .rename('precip_mm'))

# 1) Grid cells (1 degree squares)
grid = pd.read_csv('earth_grid_land.csv')[['lat', 'lon']].copy()
grid['site'] = grid.apply(lambda r: f"cell {r.lat},{r.lon}", axis=1)

feats = [ee.Feature(
    ee.Geometry.Rectangle([r.lon - 0.5, r.lat - 0.5, r.lon + 0.5, r.lat + 0.5]),
    {'site': r.site, 'lat': r.lat, 'lon': r.lon}) for r in grid.itertuples()]

# 2) Known sites (10 km circles)
known = pd.read_csv('earth_samples_v2.csv')[['site', 'lat', 'lon']]
feats += [ee.Feature(
    ee.Geometry.Point([r.lon, r.lat]).buffer(10000),
    {'site': r.site, 'lat': r.lat, 'lon': r.lon}) for r in known.itertuples()]

rows = []
for i in range(0, len(feats), 200):
    fc = ee.FeatureCollection(feats[i:i + 200])
    res = precip.reduceRegions(collection=fc, reducer=ee.Reducer.mean(),
                               scale=10000).getInfo()
    rows += [f['properties'] for f in res['features']]
    print(f"Done {min(i + 200, len(feats))}/{len(feats)}")

df = pd.DataFrame(rows).rename(columns={'mean': 'precip_mm'})
df.to_csv('precip.csv', index=False)
print(df.sort_values('precip_mm').head(10).round(1).to_string(index=False))
print(df[df['site'].isin(known['site'])].round(1).to_string(index=False))