import ee
import pandas as pd

ee.Initialize(project='twinworld-spaceapps')

SITES = [
   ("Wadi Rum, Jordan", 29.5739, 35.4216),
    ("Atacama Desert, Chile", -24.5000, -69.2500),
    ("Haughton Crater, Canada", 75.3800, -89.8800),
    ("Death Valley, USA", 36.5323, -116.9325),
    ("Dallol, Ethiopia", 14.2417, 40.2989),
    ("Mauna Loa, Hawaii", 19.4795, -155.5922),
    ("Dry Valleys, Antarctica", -77.5000, 162.0000),
    ("Lut Desert, Iran", 30.5000, 59.0000),
    ("Harrat Rahat, Saudi Arabia", 24.0000, 40.0000),
    ("Lanzarote, Spain", 29.0469, -13.6310),
    ("Svalbard, Norway", 78.2232, 15.6267),
    ("Ries Crater, Germany", 48.8833, 10.5500),
    ("Rio Tinto, Spain", 37.6800, -6.5700),
    ("Lonar Crater, India", 19.9800, 76.5100),
    ("Mojave Desert, USA", 35.0000, -116.5000),
    ("Namib Desert, Namibia", -24.5000, 15.0000),
    ("Icelandic Volcanic Fields, Iceland", 65.0000, -17.0000),
    ("Kīlauea Volcano, Hawaii, USA", 19.4300, -155.2900),
    ("Qaidam Basin, China", 37.0000, 95.0000),
    ("Pilbara Craton, Australia", -22.0000, 118.0000),
    ("Yellowstone, USA", 44.6000, -110.5000),
    ("Sudbury Impact Structure, Canada", 46.5000, -81.0000),

    # --- القائمة الإضافية (23-44) ---
    ("Laguna Negra, Chile", -33.6500, -70.1300),
    ("McLaughlin Natural Reserve, USA", 38.8700, -122.4000),
    ("Mistaken Point, Canada", 46.6300, -53.1800),
    ("Moab, Utah, USA", 38.5700, -109.5500),
    ("The Cedars, California, USA", 38.7000, -123.1000),
    ("Transvaal Basin, South Africa", -26.1000, 27.5000),
    ("Lava Beds National Monument, USA", 41.7000, -121.5000),
    ("Cinder Lake Crater Field, USA", 35.3000, -111.7000),
    ("SP Mountain, Arizona, USA", 35.6000, -111.6000),
    ("Hopi Buttes, Arizona, USA", 35.8000, -110.5000),
    ("Sunset Crater, Arizona, USA", 35.3700, -111.5000),
    ("Meteor Crater, Arizona, USA", 35.0270, -111.0220),
    ("Verde Valley, Arizona, USA", 34.6000, -111.9000),
    ("Aden Crater, New Mexico, USA", 32.0000, -107.0000),
    ("Black Point Lava Flow, Arizona, USA", 35.6700, -111.4000),
    ("Mendenhall Glacier, Alaska, USA", 58.4000, -134.5500),
    ("Lake Salda, Turkey", 37.5000, 29.7000),
    ("San Rafael Swell, Utah, USA", 38.8000, -110.7000),
]

RADIUS = 10000 
SCALE = 250     

proj = ee.Projection('EPSG:4326').atScale(SCALE)

# ارتفاع: NASADEM حيث متوفر (حتى 60N)، وGMTED2010 للقطبين
nasadem = (ee.Image('NASA/NASADEM_HGT/001').select('elevation')
           .toFloat()
           .reduceResolution(ee.Reducer.mean(), maxPixels=1024)
           .reproject(proj))
gmted = (ee.Image('USGS/GMTED2010').select('be75')
         .rename('elevation').toFloat().reproject(proj))

slope_n = ee.Terrain.slope(nasadem)
slope_g = ee.Terrain.slope(gmted)

elevation = ee.ImageCollection([gmted, nasadem]).mosaic().rename('elevation')
slope = ee.ImageCollection([slope_g, slope_n]).mosaic().rename('slope')

# MODIS حرارة السطح
lst = (ee.ImageCollection('MODIS/061/MOD11A2')
       .filterDate('2023-01-01', '2024-01-01'))
day = lst.select('LST_Day_1km').mean().multiply(0.02).subtract(273.15)
night = lst.select('LST_Night_1km').mean().multiply(0.02).subtract(273.15)
thermal_range = day.subtract(night).rename('thermal_range')
mean_temp = day.add(night).divide(2).rename('mean_temp')

# MODIS NDVI
ndvi = (ee.ImageCollection('MODIS/061/MOD13A2')
        .filterDate('2023-01-01', '2024-01-01')
        .select('NDVI').mean().multiply(0.0001).rename('ndvi'))

stack = (elevation.addBands(slope).addBands(thermal_range)
         .addBands(mean_temp).addBands(ndvi))

reducer = ee.Reducer.mean().combine(ee.Reducer.stdDev(), sharedInputs=True)

rows = []
for name, lat, lon in SITES:
    area = ee.Geometry.Point([lon, lat]).buffer(RADIUS)
    try:
        s = stack.reduceRegion(
            reducer=reducer, geometry=area, scale=SCALE, maxPixels=1e9
        ).getInfo()
        s.update({'site': name, 'lat': lat, 'lon': lon})
        rows.append(s)
        print(f"OK  {name}")
    except Exception as e:
        print(f"ERR {name}: {e}")

df = pd.DataFrame(rows)
# مناطق ثلجية/ليل قطبي ما فيها NDVI صالح: نعتبرها بدون نبات
df['ndvi_mean'] = df['ndvi_mean'].fillna(0)
df['ndvi_stdDev'] = df['ndvi_stdDev'].fillna(0)

df.to_csv('earth_samples_v2.csv', index=False)
print(df.round(2).to_string())