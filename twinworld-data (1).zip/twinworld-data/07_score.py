import pandas as pd
import numpy as np

# Load test grid (Arabian Peninsula) and the 12 known sites
grid = pd.read_csv('earth_grid_land.csv')
grid['site'] = grid.apply(lambda r: f"cell {r.lat},{r.lon}", axis=1)
grid['kind'] = 'grid'

known = pd.read_csv('earth_samples_v2.csv')
known['kind'] = 'known'

keep = ['site', 'kind', 'lat', 'lon', 'slope_mean', 'ndvi_mean', 'mean_temp_mean']
pool = pd.concat([grid[keep], known[keep]], ignore_index=True)

# Percentile score per dimension (0 to 1)
pool['s_steep'] = pool['slope_mean'].rank(pct=True)           # steeper is better
pool['s_veg'] = 1 - pool['ndvi_mean'].rank(pct=True)          # less vegetation is better
pool['s_cold'] = 1 - pool['mean_temp_mean'].rank(pct=True)    # colder is better

weights = {'s_steep': 0.4, 's_veg': 0.3, 's_cold': 0.3}

# Require all 3 dimensions to be valid
dims = list(weights.keys())
pool['n_dims'] = pool[dims].notna().sum(axis=1)
pool['score'] = sum(pool[k] * w for k, w in weights.items())  # NaN if any is missing
pool.loc[pool['n_dims'] < len(dims), 'score'] = np.nan

incomplete = pool[pool['score'].isna()]
print("Excluded (incomplete data):", incomplete['site'].tolist())

pool = pool.dropna(subset=['score'])
pool = pool.sort_values('score', ascending=False).reset_index(drop=True)
pool['rank'] = pool.index + 1
pool.to_csv('scores_test.csv', index=False)

show = ['rank', 'site', 'score', 's_steep', 's_veg', 's_cold']
print("\nTOP 10 overall:")
print(pool[show].head(10).round(2).to_string(index=False))

print("\nKnown analog sites:")
print(pool[pool['kind'] == 'known'][show].round(2).to_string(index=False))
print("\nTotal places ranked:", len(pool))