(function () {
  var TARGETS = {
    shackleton: 'image/shackleton.jpg',
    jezero: 'image/jezero.jpg',
    gale: 'image/gale.webp',
    tranquillitatis: 'image/tranquillitatis.png',
    meridiani: 'image/meridiani.jpg'     
  };
  var SITES = {
    'Wadi Rum': 'image/wadiRum.jpg', 'Atacama Desert': 'image/Atacama.jpg',
    'Haughton Crater': 'image/Haughton.jpg', 'Death Valley': 'image/Death.jpg',
    'Dallol': 'image/Dallol.jpg', 'Mauna Loa': 'image/maunaLoa.jpg',
    'Dry Valleys': 'image/Dry Valleys.jpg', 'Lut Desert': 'image/Lut Desert.jpg',
    'Harrat Rahat': 'image/Harrat Rahat.jpg', 'Lanzarote': 'image/Lanzarote.jpg',
    'Svalbard': 'image/Svalbard.jpg', 'Ries Crater': 'image/Ries Crater.jpg',
    'Rio Tinto': 'image/Rio Tinto.jpg', 'Lonar Crater': 'image/Lonar Crater.jpg',
    'Mojave Desert': 'image/Mojave Desert.jpg', 'Namib Desert': 'image/Namib Desert.jpg',
    'Icelandic Volcanic Fields': 'image/Icelandic Volcanic Fields.jpg',
    'Kilauea Volcano': 'image/Kilauea Volcano.jpg', 'Qaidam Basin': 'image/Qaidam Basin.png',
    'Pilbara Craton': 'image/Pilbara Craton.jpg', 'Yellowstone': 'image/Yellowstone.jpg',
    'Sudbury Impact Structure': 'image/Sudbury Impact Structure.jpg',
    'Laguna Negra': 'image/Laguna Negra.jpg',
    'McLaughlin Natural Reserve': 'image/mclaughlin-natural-reserve.jpg',
    'Mistaken Point': 'image/Mistaken Point.jpg', 'Moab': 'image/Moab.jpg',
    'The Cedars': 'image/the-cedars.jpg', 'Transvaal Basin': 'image/Transvaal Basin.jpg',
    'Lava Beds National Monument': 'image/Lava Beds National Monument.jpg',
    'Cinder Lake Crater Field': 'image/Cinder Lake Crater Field.jpg',
    'SP Mountain': 'image/SP Mountain.jpg', 'Hopi Buttes': 'image/Hopi Buttes.jpg',
    'Sunset Crater': 'image/Sunset Crater.jpg', 'Meteor Crater': 'image/Meteor Crater.jpg',
    'Verde Valley': 'image/Verde Valley.jpg', 'Aden Crater': 'image/Aden Crater.jpg',
    'Black Point Lava Flow': 'image/Black Point Lava Flow.jpg',
    'Mendenhall Glacier': 'image/Mendenhall Glacier.jpg', 'Lake Salda': 'image/Lake Salda.jpg',
    'San Rafael Swell': 'image/San Rafael Swell.jpg'
  };

  // lowercase letters and digits only, accents removed (so Kīlauea matches Kilauea)
  function norm(s) {
    return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');
  }
  var N = {};
  Object.keys(SITES).forEach(function (k) { N[norm(k)] = SITES[k]; });

  function forName(name) {
    var n = norm(String(name || '').split(',')[0]);
    if (!n) return null;
    if (N[n]) return N[n];
    var keys = Object.keys(N);
    for (var i = 0; i < keys.length; i++) {
      if (n.indexOf(keys[i]) !== -1 || keys[i].indexOf(n) !== -1) return N[keys[i]];
    }
    return null;
  }

  window.TWIMG = {
    forTarget: function (id) { return TARGETS[id] || null; },
    forSite: function (r) { return (!r || r.kind === 'grid') ? null : forName(r.site); },
    forName: forName
  };
})();