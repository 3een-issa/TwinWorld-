window.TW = {
  load() { return Promise.resolve(window.SCORES); }
};