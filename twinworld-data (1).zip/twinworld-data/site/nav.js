
(function () {
    var ACTIVE = document.currentScript.dataset.active;

    var PAGES = [
        { id: 'home', label: 'Home', icon: 'home', href: 'index.html', ready: true },
        { id: 'builder', label: 'Mission Builder', icon: 'rocket_launch', href: 'mission-builder.html', ready: true },
        { id: 'results', label: 'Results', icon: 'bar_chart', href: 'results.html', ready: true },
        { id: 'validation', label: 'Validation', icon: 'verified_user', href: 'validation.html', ready: true },
        { id: 'methodology', label: 'Methodology', icon: 'menu_book', href: 'methodology.html', ready: true }
    ];

    var css =
        '.nav-capsule{background:rgba(15,23,22,.78);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);' +
        'border:1px solid rgba(255, 255, 255, 0.02);box-shadow:0 16px 40px -10px rgba(0,0,0,.65),inset 0 1px 0 rgba(255,255,255,.08);' +
        'transition:transform .4s cubic-bezier(.16,1,.3,1),opacity .4s ease,background .3s ease}' +
        '.nav-capsule.nav-scrolled-down{transform:translate(-50%,-130%);opacity:0}' +
        '.nav-capsule.nav-scrolled-up{transform:translate(-50%,0);opacity:1;background:rgba(13,20,19,.92)}';
    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);

    var links = PAGES.map(function (p) {
        var icon = '<span class="material-symbols-outlined text-[17px]">' + p.icon + '</span>';
        if (!p.ready) {
            return '<span title="Coming soon" class="px-3.5 py-1.5 flex items-center gap-2 text-[13px] font-medium text-slate-500 cursor-not-allowed">' +
                icon + '<span>' + p.label + '</span>' +
                '<span class="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-white/10 text-slate-400">soon</span></span>';
        }
        var on = p.id === ACTIVE;
        return '<a href="' + p.href + '" class="relative px-3.5 py-1.5 flex items-center gap-2 text-[13px] font-medium ' +
            (on ? 'text-white' : 'text-slate-300 hover:text-white hover:bg-white/5 rounded-full transition-colors') + '">' +
            icon + '<span>' + p.label + '</span>' +
            (on ? '<span class="absolute bottom-0 left-3 right-3 h-[2px] bg-gradient-to-r from-amber-600 via-orange-500 to-amber-500 rounded-full"></span>' : '') +
            '</a>';
    }).join('');

    var html =
        '<header id="main-header" class="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-[94%] max-w-[1240px] nav-capsule rounded-full px-4 sm:px-6 py-2.5 sm:py-3">' +
        '<div class="flex items-center justify-between gap-4">' +
        '<a href="index.html" class="flex items-center gap-2.5 group flex-shrink-0">' +
         '<img src="image/logo.png" alt="TwinWorld Logo" class="w-15 h-10 object-contain">'  +
         
        '</a>' +
        '<nav class="hidden md:flex items-center gap-1 lg:gap-2">' + links + '</nav>' +
        '<a href="mission-builder.html" class="inline-flex items-center gap-1.5 px-4 sm:px-5 py-1.5 sm:py-2 rounded-full font-medium text-xs sm:text-[13px] text-emerald-100 bg-[#263D35] hover:bg-[#2d493f] border border-emerald-500/30 hover:border-emerald-400/50 transition-all">' +
        '<span>Start Mission</span><span class="material-symbols-outlined text-[15px] -rotate-45">arrow_forward</span></a>' +
        '</div>' +
        '</header>';
    document.body.insertAdjacentHTML('afterbegin', html);

    // Hide on scroll down, show on scroll up
    var header = document.getElementById('main-header');
    var lastY = window.scrollY;
    window.addEventListener('scroll', function () {
        var y = window.scrollY;
        if (y <= 60) {
            header.classList.remove('nav-scrolled-down', 'nav-scrolled-up');
        } else if (y > lastY && y > 150) {
            header.classList.add('nav-scrolled-down');
            header.classList.remove('nav-scrolled-up');
        } else if (y < lastY) {
            header.classList.remove('nav-scrolled-down');
            header.classList.add('nav-scrolled-up');
        }
        lastY = y;
    }, { passive: true });
})();