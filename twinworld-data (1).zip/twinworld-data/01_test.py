import ee

ee.Initialize(project='twinworld-spaceapps')

wadi_rum = ee.Geometry.Point([35.4216, 29.5739])
area = wadi_rum.buffer(5000)

dem = ee.Image('NASA/NASADEM_HGT/001').select('elevation')
slope = ee.Terrain.slope(dem)

stats = dem.addBands(slope).reduceRegion(
    reducer=ee.Reducer.mean(),
    geometry=area,
    scale=30,
).getInfo()

print("Wadi Rum (5 km radius):")
print(f"  Mean elevation: {stats['elevation']:.0f} m")
print(f"  Mean slope:     {stats['slope']:.1f} degrees")