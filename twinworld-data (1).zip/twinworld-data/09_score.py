import pandas as pd
import numpy as np

# 1. Load grid and known sites
grid = pd.read_csv('earth_grid_land.csv')
grid['site'] = grid.apply(lambda r: f"cell {r.lat},{r.lon}", axis=1)
grid['kind'] = 'grid'

known = pd.read_csv('earth_samples_v2.csv')
known['kind'] = 'known'

keep = ['site', 'kind', 'lat', 'lon', 'slope_mean', 'ndvi_mean', 'mean_temp_mean']
pool = pd.concat([grid[keep], known[keep]], ignore_index=True)

# 2. Load precipitation data and merge
precip_df = pd.read_csv('precip.csv')[['site', 'precip_mm']]
pool = pd.merge(pool, precip_df, on='site', how='left')

# 3. Percentile score per dimension (0 to 1)
pool['s_steep'] = pool['slope_mean'].rank(pct=True)              # steeper is better
pool['s_veg'] = 1 - pool['ndvi_mean'].rank(pct=True)             # less vegetation is better
pool['s_cold'] = 1 - pool['mean_temp_mean'].rank(pct=True)       # colder is better
pool['s_dry'] = 1 - pool['precip_mm'].rank(pct=True)             # drier is better

# 4. Weights configuration (4 dimensions, balanced 0.25 each)
weights = {
    's_steep': 0.25, 
    's_veg': 0.25, 
    's_cold': 0.25, 
    's_dry': 0.25
}

# 5. Require all 4 dimensions to be valid
dims = list(weights.keys())
pool['n_dims'] = pool[dims].notna().sum(axis=1)
pool['score'] = sum(pool[k] * w for k, w in weights.items())  # NaN if any is missing
pool.loc[pool['n_dims'] < len(dims), 'score'] = np.nan

incomplete = pool[pool['score'].isna()]
print("Excluded (incomplete data):", incomplete['site'].tolist())

pool = pool.dropna(subset=['score'])
pool = pool.sort_values('score', ascending=False).reset_index(drop=True)
pool['rank'] = pool.index + 1
pool.to_csv('scores_test_4dim.csv', index=False)

show = ['rank', 'site', 'score', 's_steep', 's_veg', 's_cold', 's_dry']
print("\nTOP 10 overall (4-Dimension Model):")
print(pool[show].head(10).round(2).to_string(index=False))

print("\nKnown analog sites (4-Dimension Model):")
print(pool[pool['kind'] == 'known'][show].round(2).to_string(index=False))
print("\nTotal places ranked:", len(pool))
# حفظ النتائج بصيغة JSON لتسهيل قراءتها من الـ Frontend
pool.to_json('scores.json', orient='records', force_ascii=False)