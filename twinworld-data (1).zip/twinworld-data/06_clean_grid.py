import pandas as pd

df = pd.read_csv('earth_grid.csv')
print("Total cells:", len(df))

# MODIS LST exists only over land, so a missing value means water.
# Also drop cells with no valid NDVI (water, ice, or no valid pixels).
land = df.dropna(subset=['thermal_range_mean', 'mean_temp_mean', 'ndvi_mean']).copy()
print("Land cells kept:", len(land))
print("Cells removed:", len(df) - len(land))

land.to_csv('earth_grid_land.csv', index=False)

print("\nSummary of land cells:")
print(land[['elevation_mean', 'slope_mean', 'thermal_range_mean',
            'mean_temp_mean', 'ndvi_mean']].describe().round(2).to_string())